var structfeatures__info__s =
[
    [ "annotations", "structfeatures__info__s.html#aae729233b05b0da656c538fdb721fcaa", null ],
    [ "hooks", "structfeatures__info__s.html#a1232e72aacf4406288c0c3f60da97923", null ],
    [ "linux", "structfeatures__info__s.html#a591e84545c5bd5796c1929ec235c7d1e", null ],
    [ "mount_options", "structfeatures__info__s.html#a3fd59cef717812f93493b9601ed4faea", null ],
    [ "oci_version_max", "structfeatures__info__s.html#a56b0e7507c2ffab58ca3c1335f6d7644", null ],
    [ "oci_version_min", "structfeatures__info__s.html#acfcec235cd42531fa0c97f0dfa5dd2bb", null ],
    [ "potentially_unsafe_annotations", "structfeatures__info__s.html#a7b417ddb061013ff209e6408a906ef04", null ]
];