var structcustom__handler__instance__s =
[
    [ "cookie", "structcustom__handler__instance__s.html#a678642cec3ed176c590eb7b2c8133177", null ],
    [ "vtable", "structcustom__handler__instance__s.html#a3e38628d365610881765ea3e42cc8d94", null ]
];