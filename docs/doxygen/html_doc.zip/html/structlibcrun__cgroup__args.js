var structlibcrun__cgroup__args =
[
    [ "annotations", "structlibcrun__cgroup__args.html#a75105109434c7a9681b7c4727539c815", null ],
    [ "cgroup_path", "structlibcrun__cgroup__args.html#a2010aea1f4fd513e1ee0bcaf503fb910", null ],
    [ "id", "structlibcrun__cgroup__args.html#aeffa2f0815ce90fecbda9aac199143db", null ],
    [ "joined", "structlibcrun__cgroup__args.html#a946ecd7736a57660616885580a02b2ce", null ],
    [ "manager", "structlibcrun__cgroup__args.html#ac3efaeee9162eba20dcf4711263a6661", null ],
    [ "pid", "structlibcrun__cgroup__args.html#ae0d46a978d5cd6707411f276ad869b9c", null ],
    [ "resources", "structlibcrun__cgroup__args.html#a73c5378be8db29c26d1861948f80a3ef", null ],
    [ "root_gid", "structlibcrun__cgroup__args.html#ae454e76826c9df55f84a8ec07e791bab", null ],
    [ "root_uid", "structlibcrun__cgroup__args.html#ac7e6252944c4957ef40264098f0d89f4", null ],
    [ "state_root", "structlibcrun__cgroup__args.html#a202470d913c43bb7982775f53a31a4fd", null ]
];