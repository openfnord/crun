var structprivate__data__s =
[
    [ "container_notify_socket_path", "structprivate__data__s.html#a31b785f1f39d31abd8055a942702679e", null ],
    [ "deny_setgroups", "structprivate__data__s.html#ad210381914d95bc3718eecdc0ded87f7", null ],
    [ "dev_fds", "structprivate__data__s.html#a6f2cd3b65a15fe9f27c07e820063b11d", null ],
    [ "external_descriptors", "structprivate__data__s.html#aa4d369a6be7fbd91a4926044b56c479c", null ],
    [ "host_notify_socket_path", "structprivate__data__s.html#ae5bb8ad6f90062df8b758428724072f1", null ],
    [ "mount_dev_from_host", "structprivate__data__s.html#ada6a00bf4c9fd7d22b96632436068d5a", null ],
    [ "mount_fds", "structprivate__data__s.html#a7d5ebfe41881dc980af1f36ccff68b85", null ],
    [ "notify_socket_tree_fd", "structprivate__data__s.html#af2cf6dc9b269d0ed762ce74bd022eaa0", null ],
    [ "remounts", "structprivate__data__s.html#a082a647c09bfa78a93249f835c18fd69", null ],
    [ "rootfs", "structprivate__data__s.html#aa1c88307eb8cd6b5c5f35341e083a679", null ],
    [ "rootfs_propagation", "structprivate__data__s.html#aeac59e85c62e6362a3d7c40a4db22a85", null ],
    [ "rootfsfd", "structprivate__data__s.html#aaf0a1b3adb931ab61c499c5b74a2da93", null ],
    [ "unshare_cgroupns", "structprivate__data__s.html#a365cb008584838804103808d1422834f", null ],
    [ "unshare_flags", "structprivate__data__s.html#ae38f4dbf5141a78db3fd7de73b244fd8", null ]
];