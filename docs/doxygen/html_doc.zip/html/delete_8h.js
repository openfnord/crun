var delete_8h =
[
    [ "crun_command_delete", "delete_8h.html#ac5a6aedf169a2fac7d5e58de2ed6e48b", null ]
];