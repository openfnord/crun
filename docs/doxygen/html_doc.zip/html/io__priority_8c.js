var io__priority_8c =
[
    [ "_GNU_SOURCE", "io__priority_8c.html#a369266c24eacffb87046522897a570d5", null ],
    [ "libcrun_set_io_priority", "io__priority_8c.html#a904cf33ca371c852a7ec0a34b8330d9b", null ]
];