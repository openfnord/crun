var structlibcrun__load__seccomp__notify__conf__s =
[
    [ "bundle_path", "structlibcrun__load__seccomp__notify__conf__s.html#ad4c9d627536deae9e9d2ce03b3286d97", null ],
    [ "name", "structlibcrun__load__seccomp__notify__conf__s.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "oci_config_path", "structlibcrun__load__seccomp__notify__conf__s.html#ae9890bebbc766b1ed61abcd7969f0f58", null ],
    [ "runtime_root_path", "structlibcrun__load__seccomp__notify__conf__s.html#a97dcc86708641feb891af9fd682e15d8", null ]
];