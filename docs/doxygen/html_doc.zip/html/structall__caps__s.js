var structall__caps__s =
[
    [ "ambient", "structall__caps__s.html#a834f651d39f06401c7d1f066d61da926", null ],
    [ "bounding", "structall__caps__s.html#aa77e2f21f8afb7bdd99a14d95864a2f0", null ],
    [ "effective", "structall__caps__s.html#a6b65a5bd34bab3fc6fa04537f9ae9fe1", null ],
    [ "inheritable", "structall__caps__s.html#a36b2665d11708303025581f791faec4e", null ],
    [ "permitted", "structall__caps__s.html#a225710fd0b6a9296af5cb09fbc29b6b7", null ]
];