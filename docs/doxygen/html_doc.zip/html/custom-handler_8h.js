var custom_handler_8h =
[
    [ "custom_handler_s", "structcustom__handler__s.html", "structcustom__handler__s" ],
    [ "custom_handler_instance_s", "structcustom__handler__instance__s.html", "structcustom__handler__instance__s" ],
    [ "cleanup_custom_handler_instance", "custom-handler_8h.html#a035078502082e9ca5e7647cb7a4b9b85", null ],
    [ "run_oci_get_handler_cb", "custom-handler_8h.html#a4c92e7c104a9d9f0ce3c0b224bcf090a", null ],
    [ "cleanup_custom_handler_instancep", "custom-handler_8h.html#a8afd1b33e4afe9850994d8e7000810e4", null ],
    [ "handler_by_name", "custom-handler_8h.html#aaaf64eae45f4269864613bc425d7ef91", null ],
    [ "handler_manager_free", "custom-handler_8h.html#a7049541ef6a62873691ce61e157861ad", null ],
    [ "libcrun_configure_handler", "custom-handler_8h.html#afbac3f76cf439e4c62857c09438a9407", null ],
    [ "libcrun_handler_manager_create", "custom-handler_8h.html#a0a65d77c4d7fa5b195f913109e6c9c1b", null ],
    [ "libcrun_handler_manager_load_directory", "custom-handler_8h.html#a17b5210948edddf26d6dece549d0ad8c", null ],
    [ "libcrun_handler_manager_print_feature_tags", "custom-handler_8h.html#a29b8bf824484c7973d5988dff20f735c", null ]
];