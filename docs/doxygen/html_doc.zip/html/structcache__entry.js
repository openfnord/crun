var structcache__entry =
[
    [ "atime", "structcache__entry.html#ae9d95e604a4085e3961ec747e8e133bf", null ],
    [ "checksum", "structcache__entry.html#a5a6d8f87f68d3a5cad0889da3b3aceab", null ]
];