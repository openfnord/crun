var structwait__for__process__args =
[
    [ "container_ready_fd", "structwait__for__process__args.html#ab65786cb6bc2808e2caa9d729b25abf6", null ],
    [ "context", "structwait__for__process__args.html#a25e200d2336d9affb2448df2e3964116", null ],
    [ "notify_socket", "structwait__for__process__args.html#aba0e4445b52d3268cbbf15ecd139cccf", null ],
    [ "pid", "structwait__for__process__args.html#ae0d46a978d5cd6707411f276ad869b9c", null ],
    [ "seccomp_notify_fd", "structwait__for__process__args.html#a1dc75547602b67a56ec0c4908ba70296", null ],
    [ "seccomp_notify_plugins", "structwait__for__process__args.html#aa3fea9adcc06db8a9dee1a377148d968", null ],
    [ "terminal_fd", "structwait__for__process__args.html#a3d39bd4f9f4146c6d6bfc69696bca85b", null ]
];