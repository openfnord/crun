var scheduler_8c =
[
    [ "sched_attr_s", "structsched__attr__s.html", "structsched__attr__s" ],
    [ "_GNU_SOURCE", "scheduler_8c.html#a369266c24eacffb87046522897a570d5", null ],
    [ "SCHED_FLAG_DL_OVERRUN", "scheduler_8c.html#a17f7a0959db28a9a5a1678aee266310d", null ],
    [ "SCHED_FLAG_KEEP_PARAMS", "scheduler_8c.html#a13df7c33ef4dc19d9ec7a2e5911e4e56", null ],
    [ "SCHED_FLAG_KEEP_POLICY", "scheduler_8c.html#ab287b54fe19b565ee8e2419060cde681", null ],
    [ "SCHED_FLAG_RECLAIM", "scheduler_8c.html#a2c327f8006787f60e0361df4568bc637", null ],
    [ "SCHED_FLAG_RESET_ON_FORK", "scheduler_8c.html#a3a4eaed50db678ffbdfdebaee81be499", null ],
    [ "SCHED_FLAG_UTIL_CLAMP_MAX", "scheduler_8c.html#a64132f911285fa2ead551c3e69b2b9c2", null ],
    [ "SCHED_FLAG_UTIL_CLAMP_MIN", "scheduler_8c.html#a5a2fe308d539a82ba2089573e860260c", null ],
    [ "libcrun_reset_cpu_affinity_mask", "scheduler_8c.html#a3e68d2bceb19b008c62fc09973ecc0f1", null ],
    [ "libcrun_set_cpu_affinity_from_string", "scheduler_8c.html#a1ff82b211bbdfdecbcb3af599a019b51", null ],
    [ "libcrun_set_scheduler", "scheduler_8c.html#aea8fa7fa2cb66447718ef5551e72010a", null ],
    [ "syscall_sched_setattr", "scheduler_8c.html#a12759c5c2e62ad113404ab0165837776", null ]
];