var searchData=
[
  ['derive_5fkey_5fcontext_0',['DERIVE_KEY_CONTEXT',['../blake3__impl_8h.html#af1f12c808c513e84d39a88930812b5cba891ca3ed53dd8464f1aa3bc5ca792cce',1,'blake3_impl.h']]],
  ['derive_5fkey_5fmaterial_1',['DERIVE_KEY_MATERIAL',['../blake3__impl_8h.html#af1f12c808c513e84d39a88930812b5cba399b62381341913e02639d8e1d3e8744',1,'blake3_impl.h']]]
];
