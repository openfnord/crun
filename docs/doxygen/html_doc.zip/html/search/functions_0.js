var searchData=
[
  ['_5f_5fattribute_5f_5f_0',['__attribute__',['../utils_8h.html#a18b29a48209bf6b87580ae7640357894',1,'__attribute__((malloc)) static inline void *xmalloc(size_t size):&#160;utils.h'],['../error_8c.html#a93b9cf91f7623d6d8b100a3693d6d5e4',1,'__attribute__((noreturn)):&#160;error.c'],['../linux_8c.html#a36f229bbda63818246ec86181b1fdd42',1,'__attribute__((unused)):&#160;linux.c'],['../linux_8c.html#aafaf04447b9accd478fb9d31a839870c',1,'__attribute__((noreturn)):&#160;linux.c'],['../linux_8c.html#a083b2e840cc4afee2f08f66c46f4d64d',1,'__attribute__((constructor)):&#160;linux.c'],['../utils_8c.html#a1a1c8271d7eda51946bbed8bdd5b3251',1,'__attribute__((__noreturn__)):&#160;utils.c']]]
];
