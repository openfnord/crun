var searchData=
[
  ['open_5ffile_5fand_5fcheck_5fcontrollers_5fat_0',['open_file_and_check_controllers_at',['../cgroup-resources_8c.html#a1015fc2de9df129363709cc19b25adc9',1,'cgroup-resources.c']]],
  ['open_5fhooks_5foutput_1',['open_hooks_output',['../container_8c.html#ad95c365fa5438e96600aa972a30ca3a2',1,'container.c']]],
  ['open_5fmount_5fof_5ftype_2',['open_mount_of_type',['../linux_8c.html#abcd3468bee033895746bab714873f4dd',1,'linux.c']]],
  ['open_5fmount_5ftarget_3',['open_mount_target',['../linux_8c.html#ad8e814cf4aaad711c795a1e513772c9d',1,'linux.c']]],
  ['open_5frundir_5fdirfd_4',['open_rundir_dirfd',['../seccomp_8c.html#a14c2af0a49e6be2a2766136a59b19dce',1,'seccomp.c']]],
  ['open_5fterminal_5',['open_terminal',['../linux_8c.html#a93ea99107a212c5bfcfbc44e88333d9b',1,'linux.c']]],
  ['open_5funix_5fdomain_5fclient_5fsocket_6',['open_unix_domain_client_socket',['../utils_8h.html#af905b9c1c74f104fc0854c39e0af65ef',1,'open_unix_domain_client_socket(const char *path, int dgram, libcrun_error_t *err):&#160;utils.c'],['../utils_8c.html#af905b9c1c74f104fc0854c39e0af65ef',1,'open_unix_domain_client_socket(const char *path, int dgram, libcrun_error_t *err):&#160;utils.c']]],
  ['open_5funix_5fdomain_5fsocket_7',['open_unix_domain_socket',['../utils_8h.html#ada375f5e84b4f5e02e454948c1d36131',1,'open_unix_domain_socket(const char *path, int dgram, libcrun_error_t *err):&#160;utils.c'],['../utils_8c.html#ada375f5e84b4f5e02e454948c1d36131',1,'open_unix_domain_socket(const char *path, int dgram, libcrun_error_t *err):&#160;utils.c']]],
  ['openat_5fwith_5falias_8',['openat_with_alias',['../cgroup-resources_8c.html#a62b52c53158d4030814c194a92a2f4e7',1,'cgroup-resources.c']]],
  ['output_5fchaining_5fvalue_9',['output_chaining_value',['../blake3_8c.html#a92376f69320e66a51477df2b47088249',1,'blake3.c']]],
  ['output_5froot_5fbytes_10',['output_root_bytes',['../blake3_8c.html#a0a194eae24fe95b572091dc7e992744f',1,'blake3.c']]]
];
