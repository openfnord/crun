var searchData=
[
  ['gid_0',['gid',['../structdevice__s.html#accbf90b0b518578acff258d328c5575d',1,'device_s']]]
];
