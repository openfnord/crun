var searchData=
[
  ['tail_0',['tail',['../structring__buffer.html#ad71c3da585299fa719501f5149814fd7',1,'ring_buffer']]],
  ['target_1',['target',['../structsymlink__s.html#a16538c008062df9d79269cac260e9680',1,'symlink_s::target()'],['../structremount__s.html#a23b26cdb3a71f525caf03b57f68d47fa',1,'remount_s::target()']]],
  ['targetfd_2',['targetfd',['../structremount__s.html#a3e5d4247597eb726646c99332f2f1ec5',1,'remount_s']]],
  ['tcp_5festablished_3',['tcp_established',['../structlibcrun__checkpoint__restore__s.html#a47426a6bda8942e2b1782b5ce40bdcc6',1,'libcrun_checkpoint_restore_s']]],
  ['terminal_5ffd_4',['terminal_fd',['../structwait__for__process__args.html#a3d39bd4f9f4146c6d6bfc69696bca85b',1,'wait_for_process_args']]],
  ['terminal_5fsocketpair_5',['terminal_socketpair',['../structcontainer__entrypoint__s.html#a8d1fb4395dfe2cff333067adb8a863e9',1,'container_entrypoint_s']]],
  ['termios_6',['termios',['../structterminal__status__s.html#a57e243312fd33a59db624b1317431bad',1,'terminal_status_s']]],
  ['tls_7',['tls',['../struct__clone3__args.html#ad38969cff6fbc63bd332d3806f1a62cc',1,'_clone3_args']]],
  ['tty_8',['tty',['../structexec__options__s.html#a12ba4a1d8cf99f8d80180649dac5f674',1,'exec_options_s']]],
  ['type_9',['type',['../structdevice__s.html#a23506fc4821ab6d9671f3e6222591a96',1,'device_s::type()'],['../structdefault__dev__s.html#aff17911edc8208aa8ddb1c7c52c78389',1,'default_dev_s::type()'],['../structsync__socket__message__s.html#ac765329451135abec74c45e1897abf26',1,'sync_socket_message_s::type()']]]
];
