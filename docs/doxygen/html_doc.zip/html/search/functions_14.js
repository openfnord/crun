var searchData=
[
  ['uidgidmap_5fhelper_0',['uidgidmap_helper',['../linux_8c.html#ae3fead5495dde26d05cfc99e1a9e799b',1,'linux.c']]],
  ['umount_5for_5fhide_1',['umount_or_hide',['../linux_8c.html#a9a0a9af964961a97370685896f16b63d',1,'linux.c']]],
  ['unblock_5fsignals_2',['unblock_signals',['../container_8c.html#abd51778af6d2a30c3ac05722de992745',1,'container.c']]],
  ['unset_5fcloexec_5fflag_3',['unset_cloexec_flag',['../utils_8c.html#aa95c562d09cbec2fcef6bfd272ac8af4',1,'utils.c']]],
  ['update_5fcgroup_5fresources_4',['update_cgroup_resources',['../cgroup-resources_8c.html#ab4a3355224e196c9dab690dde5f6aee9',1,'update_cgroup_resources(const char *path, const char *state_root, runtime_spec_schema_config_linux_resources *resources, libcrun_error_t *err):&#160;cgroup-resources.c'],['../cgroup-resources_8h.html#ab4a3355224e196c9dab690dde5f6aee9',1,'update_cgroup_resources(const char *path, const char *state_root, runtime_spec_schema_config_linux_resources *resources, libcrun_error_t *err):&#160;cgroup-resources.c']]],
  ['update_5fcgroup_5fv1_5fresources_5',['update_cgroup_v1_resources',['../cgroup-resources_8c.html#a7b96d5a5807736fbda0c3ff4d28c1778',1,'cgroup-resources.c']]],
  ['update_5fcgroup_5fv2_5fresources_6',['update_cgroup_v2_resources',['../cgroup-resources_8c.html#aa37638b41bd53cd8953169db6c0a37ae',1,'cgroup-resources.c']]]
];
