var searchData=
[
  ['try_5fbindfd_0',['try_bindfd',['../cloned__binary_8c.html#af36f85835576468dc9e65597640758b0',1,'cloned_binary.c']]],
  ['try_5fbindfd_5fmount_5fapi_1',['try_bindfd_mount_api',['../cloned__binary_8c.html#a394d1dc0a63dff957617b710ab438877',1,'cloned_binary.c']]],
  ['try_5fsetns_5fwith_5fpidfd_2',['try_setns_with_pidfd',['../linux_8c.html#ae6f638da531da00ce09aaff8e5ee50da',1,'linux.c']]],
  ['try_5fumount_3',['try_umount',['../linux_8c.html#af7990a070d60a943cb1ae3ecaa03f6b6',1,'linux.c']]]
];
