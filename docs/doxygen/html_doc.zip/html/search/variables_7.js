var searchData=
[
  ['handle_0',['handle',['../structplugin.html#a81011b79683fab64ce3aff71114f8fdd',1,'plugin::handle()'],['../structkrun__config.html#a81011b79683fab64ce3aff71114f8fdd',1,'krun_config::handle()']]],
  ['handle_5fsev_1',['handle_sev',['../structkrun__config.html#a48c5c41cd00d063a2a21f8ea16c82973',1,'krun_config']]],
  ['handler_2',['handler',['../structcrun__global__arguments.html#a16631dfce3051d3a6dcced4d5e1d32f3',1,'crun_global_arguments::handler()'],['../structlibcrun__context__s.html#a16631dfce3051d3a6dcced4d5e1d32f3',1,'libcrun_context_s::handler()'],['../structcommands__s.html#ac11a11126747f758bbf331d8e6e50550',1,'commands_s::handler()']]],
  ['handler_5fmanager_3',['handler_manager',['../structlibcrun__context__s.html#a63bb1000e2e97d2792b738db7830c339',1,'libcrun_context_s::handler_manager()'],['../crun_8c.html#a63bb1000e2e97d2792b738db7830c339',1,'handler_manager():&#160;crun.c']]],
  ['handlers_4',['handlers',['../structcustom__handler__manager__s.html#a17a320ff37a55e5590b774358579c3f6',1,'custom_handler_manager_s']]],
  ['handlers_5flen_5',['handlers_len',['../structcustom__handler__manager__s.html#a7f04bcc9f12d2a0dc512a68839fdb58a',1,'custom_handler_manager_s']]],
  ['handles_6',['handles',['../structcustom__handler__manager__s.html#a3d98845581919e726145d1eec24eab46',1,'custom_handler_manager_s']]],
  ['has_5fterminal_5fsocket_5fpair_7',['has_terminal_socket_pair',['../structcontainer__entrypoint__s.html#a5e32ff82776ad8a94cd5521f193bb605',1,'container_entrypoint_s']]],
  ['head_8',['head',['../structring__buffer.html#a75844ce74940ef333d11ae090e07c9af',1,'ring_buffer']]],
  ['hooks_9',['hooks',['../structfeatures__info__s.html#a1232e72aacf4406288c0c3f60da97923',1,'features_info_s::hooks()'],['../container_8c.html#a755a795d4013804e5c86c54538d2523b',1,'hooks():&#160;container.c']]],
  ['hooks_5ferr_5ffd_10',['hooks_err_fd',['../structcontainer__entrypoint__s.html#a8c8ec3a12ef643a9cdb54c65f508ce23',1,'container_entrypoint_s']]],
  ['hooks_5fout_5ffd_11',['hooks_out_fd',['../structcontainer__entrypoint__s.html#a04bd3e1bcebc80a1583459193c4e05f2',1,'container_entrypoint_s']]],
  ['host_5fgid_12',['host_gid',['../structlibcrun__container__s.html#ac53adb1b6b7651bd7a83389e7470d723',1,'libcrun_container_s']]],
  ['host_5fnotify_5fsocket_5fpath_13',['host_notify_socket_path',['../structprivate__data__s.html#ae5bb8ad6f90062df8b758428724072f1',1,'private_data_s']]],
  ['host_5fuid_14',['host_uid',['../structlibcrun__container__s.html#a51be09749e7a4ff83dd71e5481a8c477',1,'libcrun_container_s']]]
];
