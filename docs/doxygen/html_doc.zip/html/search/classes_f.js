var searchData=
[
  ['terminal_5fstatus_5fs_0',['terminal_status_s',['../structterminal__status__s.html',1,'']]]
];
