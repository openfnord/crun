var searchData=
[
  ['n_5fplugins_0',['n_plugins',['../structseccomp__notify__context__s.html#aed61cf47679fdcdd05a9964092b59ec3',1,'seccomp_notify_context_s']]],
  ['name_1',['name',['../structlibcrun__update__value__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'libcrun_update_value_s::name()'],['../structdescription__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'description_s::name()'],['../structsignal__s.html#a456dbc08bfec1871274d887fc54f2f65',1,'signal_s::name()'],['../structlibcrun__load__seccomp__notify__conf__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'libcrun_load_seccomp_notify_conf_s::name()'],['../structrlimit__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'rlimit_s::name()'],['../structlinux__namespace__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'linux_namespace_s::name()'],['../structpropagation__flags__s.html#a5ac083a645d964373f022d03df4849c8',1,'propagation_flags_s::name()'],['../structsymlink__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'symlink_s::name()'],['../structcustom__handler__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'custom_handler_s::name()'],['../structcommands__s.html#a8f8f80d37794cde9472343e4487ba3eb',1,'commands_s::name()'],['../structlibcrun__container__list__s.html#a5ac083a645d964373f022d03df4849c8',1,'libcrun_container_list_s::name()']]],
  ['namespaces_2',['namespaces',['../structlinux__info__s.html#ac52f6ea66d1bcb38c5361920ca1892d7',1,'linux_info_s::namespaces()'],['../linux_8c.html#ab3831748cb2de936391795c028d7f6fa',1,'namespaces():&#160;linux.c'],['../container_8c.html#a5839eb416fa72da355e1df574ed53d23',1,'namespaces():&#160;container.c']]],
  ['namespaces_5fto_5funshare_3',['namespaces_to_unshare',['../structinit__status__s.html#a0057084d2734c4a3135f8c4532d9c6f1',1,'init_status_s']]],
  ['needed_5fdevs_4',['needed_devs',['../linux_8c.html#a5551b79c2f6d676df1c1684581754224',1,'linux.c']]],
  ['network_5flock_5fmethod_5',['network_lock_method',['../structlibcrun__checkpoint__restore__s.html#a0a1024c2fd5f5ad4ff62edef705cffb5',1,'libcrun_checkpoint_restore_s']]],
  ['next_6',['next',['../structremount__s.html#aac0dcf5282fd8b39bae0ad404df1df5d',1,'remount_s::next()'],['../structlibcrun__container__list__s.html#a937921dd81f8148187beca374f35d7c0',1,'libcrun_container_list_s::next()']]],
  ['nfds_7',['nfds',['../structlibcrun__fd__map.html#ab47d88a6d030ea9f30c463a63ab5a98a',1,'libcrun_fd_map']]],
  ['no_5fnew_5fkeyring_8',['no_new_keyring',['../structlibcrun__context__s.html#a09720b4670f8c996b267c3821bdc7ae0',1,'libcrun_context_s']]],
  ['no_5fnew_5fprivs_9',['no_new_privs',['../structexec__options__s.html#a5d5d61015dff7d20bf2a19756404f711',1,'exec_options_s']]],
  ['no_5fpivot_10',['no_pivot',['../structlibcrun__context__s.html#aba192c125386900a839802f7bd2c3553',1,'libcrun_context_s']]],
  ['notify_5fsocket_11',['notify_socket',['../structlibcrun__context__s.html#aacb8f7b7bf7b9488edf4f745b9dc8a38',1,'libcrun_context_s::notify_socket()'],['../structwait__for__process__args.html#aba0e4445b52d3268cbbf15ecd139cccf',1,'wait_for_process_args::notify_socket()']]],
  ['notify_5fsocket_5ftree_5ffd_12',['notify_socket_tree_fd',['../structprivate__data__s.html#af2cf6dc9b269d0ed762ce74bd022eaa0',1,'private_data_s']]],
  ['ns_5ffile_13',['ns_file',['../structlinux__namespace__s.html#af2087f1c0526029f3c2678a25770b081',1,'linux_namespace_s']]],
  ['numeric_14',['numeric',['../structlibcrun__update__value__s.html#a1b6484dcd8cfa0fc3194560041b9050e',1,'libcrun_update_value_s::numeric()'],['../structdescription__s.html#a546d85f3a54e3be6a903d3d7b4bb5219',1,'description_s::numeric()']]]
];
