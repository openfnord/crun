var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxy",
  1: "_abcdefiklmoprstuw",
  2: "bcdehiklmoprstuw",
  3: "_abcdefghijklmnoprstuvwxy",
  4: "abcdefghijklmnopqrstuvw",
  5: "chlprst",
  6: "bh",
  7: "bcdefhklmoprst",
  8: "_abcdefiklmoprstuwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

