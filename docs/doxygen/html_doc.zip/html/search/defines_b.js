var searchData=
[
  ['oom_0',['OOM',['../error_8h.html#a7b60dd9c91053f90e9a758ede59f71b5',1,'error.h']]],
  ['open_5ftree_5fcloexec_1',['OPEN_TREE_CLOEXEC',['../linux_8c.html#a4bf2fb4c284a682cdfc56895930c3ea3',1,'linux.c']]],
  ['open_5ftree_5fclone_2',['OPEN_TREE_CLONE',['../linux_8c.html#a446ee496abc9c9a81e03c80a6e6e621c',1,'linux.c']]]
];
