var structpid__stat =
[
    [ "starttime", "structpid__stat.html#a16614af99f883b4d6fb72133592522f0", null ],
    [ "state", "structpid__stat.html#afc09df66e4e1131bad27f84d29bd8726", null ]
];