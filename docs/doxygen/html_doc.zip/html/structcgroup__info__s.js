var structcgroup__info__s =
[
    [ "systemd", "structcgroup__info__s.html#a7dc93de2455e079fa39412ebb27ce3d1", null ],
    [ "systemd_user", "structcgroup__info__s.html#a18a34e50ec625e58b2ae5a83ce8639b8", null ],
    [ "v1", "structcgroup__info__s.html#aa561e40d7d58fc4f8d2b1b486ea22892", null ],
    [ "v2", "structcgroup__info__s.html#a2c79030c31e430017ed2c9a466455c7d", null ]
];