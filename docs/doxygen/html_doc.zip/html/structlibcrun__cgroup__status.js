var structlibcrun__cgroup__status =
[
    [ "manager", "structlibcrun__cgroup__status.html#ac3efaeee9162eba20dcf4711263a6661", null ],
    [ "path", "structlibcrun__cgroup__status.html#a44196e6a5696d10442c29e639437196e", null ],
    [ "scope", "structlibcrun__cgroup__status.html#ac022b195a01083536317d2f00df3413f", null ]
];