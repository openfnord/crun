var structlibcrun__checkpoint__restore__s =
[
    [ "console_socket", "structlibcrun__checkpoint__restore__s.html#af09eacc795e12b9142a81ae2a24e7e89", null ],
    [ "detach", "structlibcrun__checkpoint__restore__s.html#ad701bca0336afa7714a9265cea9c10cf", null ],
    [ "ext_unix_sk", "structlibcrun__checkpoint__restore__s.html#a20bce2eb3f964ae16ea613e0347085f8", null ],
    [ "file_locks", "structlibcrun__checkpoint__restore__s.html#a6f34b9faaaf3e90d7f08c60a76966dea", null ],
    [ "image_path", "structlibcrun__checkpoint__restore__s.html#a404d0d0bfc26f736b98db06412b408d8", null ],
    [ "leave_running", "structlibcrun__checkpoint__restore__s.html#a8e3fec3b4e89431082f1fb1201144890", null ],
    [ "lsm_mount_context", "structlibcrun__checkpoint__restore__s.html#acd502d1873658982f55da4008aa0ba70", null ],
    [ "lsm_profile", "structlibcrun__checkpoint__restore__s.html#ab34795c6e571383b3be8e17337011da1", null ],
    [ "manage_cgroups_mode", "structlibcrun__checkpoint__restore__s.html#ab249752c3b491a9c6b0ed34dce4fa57d", null ],
    [ "network_lock_method", "structlibcrun__checkpoint__restore__s.html#a0a1024c2fd5f5ad4ff62edef705cffb5", null ],
    [ "parent_path", "structlibcrun__checkpoint__restore__s.html#aa6f3a33403ff6b00fadb629060d31e76", null ],
    [ "pre_dump", "structlibcrun__checkpoint__restore__s.html#a41963567c7ea05beae6728525591b1aa", null ],
    [ "shell_job", "structlibcrun__checkpoint__restore__s.html#ac2f1d16218e34b654fb5f14eec5bb3b0", null ],
    [ "tcp_established", "structlibcrun__checkpoint__restore__s.html#a47426a6bda8942e2b1782b5ce40bdcc6", null ],
    [ "work_path", "structlibcrun__checkpoint__restore__s.html#af7013d5086e8d6bacaba3f64a91566cb", null ]
];