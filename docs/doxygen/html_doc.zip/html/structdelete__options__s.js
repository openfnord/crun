var structdelete__options__s =
[
    [ "force", "structdelete__options__s.html#a4b73e33b57ae387dc418906492d5f998", null ],
    [ "regex", "structdelete__options__s.html#ab624511eb86b89adbccfe7c2f1d51057", null ]
];