var structpropagation__flags__s =
[
    [ "clear", "structpropagation__flags__s.html#adce09b58735103e5e3117a2132b5de76", null ],
    [ "extra_flags", "structpropagation__flags__s.html#adc3a5d98a9efaa3a6b9a2a4f854ba37e", null ],
    [ "flags", "structpropagation__flags__s.html#ac8bf36fe0577cba66bccda3a6f7e80a4", null ],
    [ "name", "structpropagation__flags__s.html#a5ac083a645d964373f022d03df4849c8", null ]
];