var cgroup_resources_8h =
[
    [ "default_dev_s", "structdefault__dev__s.html", "structdefault__dev__s" ],
    [ "get_default_devices", "cgroup-resources_8h.html#ab26d4f6937211846b4ee33ef9f5ce0ce", null ],
    [ "update_cgroup_resources", "cgroup-resources_8h.html#ab4a3355224e196c9dab690dde5f6aee9", null ]
];