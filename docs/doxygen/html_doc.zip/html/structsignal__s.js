var structsignal__s =
[
    [ "name", "structsignal__s.html#a456dbc08bfec1871274d887fc54f2f65", null ],
    [ "value", "structsignal__s.html#ac4f474c82e82cbb89ca7c36dd52be0ed", null ]
];