var structrlimit__s =
[
    [ "name", "structrlimit__s.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "value", "structrlimit__s.html#ac4f474c82e82cbb89ca7c36dd52be0ed", null ]
];