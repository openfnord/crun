var structlibcrun__cgroup__manager =
[
    [ "create_cgroup", "structlibcrun__cgroup__manager.html#a5d5a1d3ad67c910bee2de0a2800572ab", null ],
    [ "destroy_cgroup", "structlibcrun__cgroup__manager.html#a6c49b7816cbcce4724e9d0fafb00b4fd", null ],
    [ "precreate_cgroup", "structlibcrun__cgroup__manager.html#acc5ecca873328c2ae4ecad9fcbd439c6", null ],
    [ "update_resources", "structlibcrun__cgroup__manager.html#a03782c0e7106d20ad3d5c8aeac430a80", null ]
];