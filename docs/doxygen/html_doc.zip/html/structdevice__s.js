var structdevice__s =
[
    [ "gid", "structdevice__s.html#accbf90b0b518578acff258d328c5575d", null ],
    [ "major", "structdevice__s.html#ac8947941479c38403a09c14a60b03f01", null ],
    [ "minor", "structdevice__s.html#aec7b96885baf2e6f10efbdef9d935a0b", null ],
    [ "mode", "structdevice__s.html#a1ea5d0cb93f22f7d0fdf804bd68c3326", null ],
    [ "path", "structdevice__s.html#a3b02c6de5c049804444a246f7fdf46b4", null ],
    [ "type", "structdevice__s.html#a23506fc4821ab6d9671f3e6222591a96", null ],
    [ "uid", "structdevice__s.html#a1163f413982fef86f5c8313564d8589c", null ]
];