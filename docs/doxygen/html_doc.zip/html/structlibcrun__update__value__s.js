var structlibcrun__update__value__s =
[
    [ "name", "structlibcrun__update__value__s.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "numeric", "structlibcrun__update__value__s.html#a1b6484dcd8cfa0fc3194560041b9050e", null ],
    [ "section", "structlibcrun__update__value__s.html#a6a4f19e932bc4c92841653e974164301", null ],
    [ "value", "structlibcrun__update__value__s.html#a8556878012feffc9e0beb86cd78f424d", null ]
];