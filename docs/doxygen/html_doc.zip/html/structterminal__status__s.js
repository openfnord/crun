var structterminal__status__s =
[
    [ "fd", "structterminal__status__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "termios", "structterminal__status__s.html#a57e243312fd33a59db624b1317431bad", null ]
];