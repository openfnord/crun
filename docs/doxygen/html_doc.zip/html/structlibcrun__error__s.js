var structlibcrun__error__s =
[
    [ "msg", "structlibcrun__error__s.html#a32d2f5216cddb59c7cc8fb2806a7e727", null ],
    [ "status", "structlibcrun__error__s.html#a6e27f49150e9a14580fb313cc2777e00", null ]
];