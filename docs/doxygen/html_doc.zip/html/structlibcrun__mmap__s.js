var structlibcrun__mmap__s =
[
    [ "addr", "structlibcrun__mmap__s.html#ae5bd6c22dbf0f6b5b0ae0233f8eb3704", null ],
    [ "length", "structlibcrun__mmap__s.html#ae809d5359ac030c60a30a8f0b2294b82", null ]
];