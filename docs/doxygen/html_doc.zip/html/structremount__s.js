var structremount__s =
[
    [ "data", "structremount__s.html#a91a70b77df95bd8b0830b49a094c2acb", null ],
    [ "flags", "structremount__s.html#a9e339c2784bd040b26a5112866700bff", null ],
    [ "next", "structremount__s.html#aac0dcf5282fd8b39bae0ad404df1df5d", null ],
    [ "target", "structremount__s.html#a23b26cdb3a71f525caf03b57f68d47fa", null ],
    [ "targetfd", "structremount__s.html#a3e5d4247597eb726646c99332f2f1ec5", null ]
];