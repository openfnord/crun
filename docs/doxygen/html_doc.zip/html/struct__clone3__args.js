var struct__clone3__args =
[
    [ "cgroup", "struct__clone3__args.html#ac492e62b1e2fcc698bcfc6abaf46afe7", null ],
    [ "child_tid", "struct__clone3__args.html#a7c25d53015744caddcae89e0e4261143", null ],
    [ "exit_signal", "struct__clone3__args.html#a26b6297337c96377dd0b919579573845", null ],
    [ "flags", "struct__clone3__args.html#accb6984ec61273fea82c30e548f7644c", null ],
    [ "parent_tid", "struct__clone3__args.html#a15e3ba81f014d113ae999ce7361337cc", null ],
    [ "pidfd", "struct__clone3__args.html#aee13c3b1574db5791419dabdacc1e8fc", null ],
    [ "set_tid", "struct__clone3__args.html#aceef8dcc4077a5e29f9c18b8af2b2f4f", null ],
    [ "set_tid_size", "struct__clone3__args.html#a2ac5ca231b4c314296138e8191765f6d", null ],
    [ "stack", "struct__clone3__args.html#a96f302ea01617f165182b462f31101ba", null ],
    [ "stack_size", "struct__clone3__args.html#aa4442f5cac624c47c19a88298937961e", null ],
    [ "tls", "struct__clone3__args.html#ad38969cff6fbc63bd332d3806f1a62cc", null ]
];