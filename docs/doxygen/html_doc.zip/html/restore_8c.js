var restore_8c =
[
    [ "_GNU_SOURCE", "restore_8c.html#a369266c24eacffb87046522897a570d5", null ],
    [ "crun_command_restore", "restore_8c.html#ab905cbf6ef7cec8757ee31f8a7907843", null ],
    [ "parse_opt", "restore_8c.html#a35ee63236273ebb9325c444cacf00159", null ],
    [ "args_doc", "restore_8c.html#a91b08784b3668a8a1fbe2eec1947fb9d", null ],
    [ "bundle", "restore_8c.html#a12fbdfebf45ae788e7bf1322b5dcba43", null ],
    [ "cr_options", "restore_8c.html#a319030422f73ae44ddb8eff5f0235104", null ],
    [ "crun_context", "restore_8c.html#a2b06ea052579c7cfebdffea9eac300ae", null ],
    [ "doc", "restore_8c.html#af6164deb8a824f8cb2b9147cfc3174f5", null ],
    [ "options", "restore_8c.html#abc1fd3a47aea6a8944038c9100eb9135", null ],
    [ "run_argp", "restore_8c.html#a58b4c49ccf39f93c908d2eb44c294bee", null ]
];