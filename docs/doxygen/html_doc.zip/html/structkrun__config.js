var structkrun__config =
[
    [ "ctx_id", "structkrun__config.html#a3fecf27740dacb2a46440e47af48e717", null ],
    [ "ctx_id_sev", "structkrun__config.html#a5de84a28dd6b1d13d8a05631779d7c3b", null ],
    [ "handle", "structkrun__config.html#a81011b79683fab64ce3aff71114f8fdd", null ],
    [ "handle_sev", "structkrun__config.html#a48c5c41cd00d063a2a21f8ea16c82973", null ],
    [ "sev", "structkrun__config.html#a45af9c83af629597a2b27d3c967874a4", null ]
];