var structbpf__program =
[
    [ "allocated", "structbpf__program.html#ae1bb12c74f8787980ecef2b1f772239b", null ],
    [ "private", "structbpf__program.html#a0b64ac4aa82e7c2e6d8f379bf81e3ead", null ],
    [ "program", "structbpf__program.html#a52f7bd4f3ac86a3e7f19cbfa52411ed1", null ],
    [ "used", "structbpf__program.html#ae8cc011bf3ee2d3c19743095ffc0f7a5", null ]
];