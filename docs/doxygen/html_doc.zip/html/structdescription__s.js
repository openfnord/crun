var structdescription__s =
[
    [ "id", "structdescription__s.html#a7441ef0865bcb3db9b8064dd7375c1ea", null ],
    [ "name", "structdescription__s.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "numeric", "structdescription__s.html#a546d85f3a54e3be6a903d3d7b4bb5219", null ],
    [ "section", "structdescription__s.html#a6a4f19e932bc4c92841653e974164301", null ]
];