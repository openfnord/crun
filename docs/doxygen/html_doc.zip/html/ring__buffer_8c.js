var ring__buffer_8c =
[
    [ "ring_buffer", "structring__buffer.html", "structring__buffer" ],
    [ "_GNU_SOURCE", "ring__buffer_8c.html#a369266c24eacffb87046522897a570d5", null ],
    [ "ring_buffer_advance_nocheck_head", "ring__buffer_8c.html#ae59162da1bf8cacb999285565c40c17c", null ],
    [ "ring_buffer_advance_nocheck_tail", "ring__buffer_8c.html#ab829950cbecb6bd87ba3ab4bfc3a7307", null ],
    [ "ring_buffer_free", "ring__buffer_8c.html#ae9bc707fe9460e4657e8f9e3a87eca43", null ],
    [ "ring_buffer_get_data_available", "ring__buffer_8c.html#a83717db4e2a8f425f283974955006a4d", null ],
    [ "ring_buffer_get_read_iov", "ring__buffer_8c.html#a5e7b277746fed54b16483bce770ed4c8", null ],
    [ "ring_buffer_get_size", "ring__buffer_8c.html#a8f049fec13dc13d5dd03bc6f67683d66", null ],
    [ "ring_buffer_get_space_available", "ring__buffer_8c.html#ae4c983e79d1494b3027b8a56c73cab0d", null ],
    [ "ring_buffer_get_write_iov", "ring__buffer_8c.html#ac27e248cee9e4f9e5500c20f27a2dc6c", null ],
    [ "ring_buffer_make", "ring__buffer_8c.html#ac99b01e8b0c114ae54a0aef194b2e636", null ],
    [ "ring_buffer_read", "ring__buffer_8c.html#ab4b7e81b602195677c88a129f54fc120", null ],
    [ "ring_buffer_write", "ring__buffer_8c.html#ab9dd274b9f92d1b9908debbfb73a9ed2", null ]
];