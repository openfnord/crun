var structspec__options__s =
[
    [ "rootless", "structspec__options__s.html#ad4a80f7b66ed8224b600ece265bf5fdd", null ]
];