var structlinux__namespace__s =
[
    [ "name", "structlinux__namespace__s.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "ns_file", "structlinux__namespace__s.html#af2087f1c0526029f3c2678a25770b081", null ],
    [ "value", "structlinux__namespace__s.html#ac4f474c82e82cbb89ca7c36dd52be0ed", null ]
];