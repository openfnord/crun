var structlibcrun__intel__rdt__update =
[
    [ "l3_cache_schema", "structlibcrun__intel__rdt__update.html#a4c660bd73552242487904ecf1d27af39", null ],
    [ "mem_bw_schema", "structlibcrun__intel__rdt__update.html#a55d7e2894437ee24d8c64a0c55ed7956", null ]
];