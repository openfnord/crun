var structmount__attr__s =
[
    [ "attr_clr", "structmount__attr__s.html#a69f11d28110cf3fd924f74dedb67318e", null ],
    [ "attr_set", "structmount__attr__s.html#acec4e42eb3c8aa46335197e6ded4d5c8", null ],
    [ "propagation", "structmount__attr__s.html#af35d0d6dc0a8f34b82e82ea867869eb2", null ],
    [ "userns_fd", "structmount__attr__s.html#aead9078ebf02af1b0c120a8a6c4a004a", null ]
];