var structoutput__t =
[
    [ "block", "structoutput__t.html#aa17a6b7630a61ba86991e74e92cd71ef", null ],
    [ "block_len", "structoutput__t.html#a417ea8ab9384c7bac94ef873065a079c", null ],
    [ "counter", "structoutput__t.html#a1944753ac8107ec537f75b7e0201d866", null ],
    [ "flags", "structoutput__t.html#aa2585d779da0ab21273a8d92de9a0ebe", null ],
    [ "input_cv", "structoutput__t.html#af8a8920fe448f6bcd3d6f17e77bc6e92", null ]
];