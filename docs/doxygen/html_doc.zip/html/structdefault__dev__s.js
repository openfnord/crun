var structdefault__dev__s =
[
    [ "access", "structdefault__dev__s.html#a6fd24f2f9f8a44e84fed96dff0a8df44", null ],
    [ "major", "structdefault__dev__s.html#ac8947941479c38403a09c14a60b03f01", null ],
    [ "minor", "structdefault__dev__s.html#aec7b96885baf2e6f10efbdef9d935a0b", null ],
    [ "type", "structdefault__dev__s.html#aff17911edc8208aa8ddb1c7c52c78389", null ]
];